/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ASUS
 */
public class Pendataan {
    String NIK,Nama;
    int Tulis, Coding, Wawancara;
    
    public Pendataan(String NIK, String Nama, int Tulis, int Coding, int Wawancara){
        this.NIK = NIK;
        this.Nama = Nama;
        this.Tulis = Tulis;
        this.Coding = Coding;
        this.Wawancara = Wawancara;
    }

}
